import { PlanningBody } from "@/core/view/planning/planning-body";

 
const Planning = () => {
  return <PlanningBody />;
};

export default Planning;
